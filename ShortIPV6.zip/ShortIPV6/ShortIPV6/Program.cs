﻿// See https://aka.ms/new-console-template for more information
using System.Net;

var longIPv6 = "2001:0db8:0000:0042:0000:8a2e:0370:7334";
IPAddress.TryParse(longIPv6, out var ipAddress);

Console.WriteLine($"long IPV6: {longIPv6}");
Console.WriteLine($"short Version: {ipAddress?.ToString()}");
IPAddress.TryParse("::1", out var ipAddress2);
if (ipAddress2.AddressFamily == System.Net.Sockets.AddressFamily.InterNetworkV6)
{
    Console.WriteLine(ipAddress2.ToString());
}
